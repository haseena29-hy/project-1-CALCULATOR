# CalculatorApp

## Description
  * Hey!,This project name is CalculatorApp and this is a simple java Project based on java Swing and GUI. It can performs arithmetic operations on numbers like:
    addition, subtraction, multiplication, and division. and It can also calculate percentage (%) of given number. 
  * There is  on/off button by using this we can off it whenever we are not using. and at of usage we can also on it. 
    this feature help in battery sever in case of real world calculator.
   
## Demo
  * Following image: [here](https://raw.githubusercontent.com/Saurabh-pec/Calculator-javaProject/main/screenshots/11.1(1)%20CalculatorPart1.jpeg).<br>
  [Img1](https://raw.githubusercontent.com/Saurabh-pec/Calculator-javaProject/main/screenshots/Screenshot%20(378).png)<br>
  [Img2](https://raw.githubusercontent.com/Saurabh-pec/Calculator-javaProject/main/screenshots/11.1(3)%20Calcu.jpeg)<br>
  [Img3](https://raw.githubusercontent.com/Saurabh-pec/Calculator-javaProject/main/screenshots/11.1(2)%20CalculatorPart2.jpeg)<br>
  
  
  Sample image look like:- 
  ![calc_img](https://raw.githubusercontent.com/Saurabh-pec/Calculator-javaProject/main/screenshots/rsz_11111_calculatorpart1.jpg)
## Technologies Used:
  * Apache netbeans 12.1
  * GUI
  * java Swing
  
## Setup/ Methods
* open java ide-'Netbeans'.
* Create a jFrame and used swing and GUI.
* import some libraries 
like:  import javax.swing.JOptionPane;
       import javax.swing.JTextField;

* Deploy buttons, panal, textfield and radiobtn etc inside the jFrame.
* Write code and set action listener on each button to perform operation.
* Run and get expected output.





 
